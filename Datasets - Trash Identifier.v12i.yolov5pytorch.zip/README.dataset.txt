# Trash Identifier > 2026-01-13 11:08pm
https://universe.roboflow.com/ignatius-bryan-oden/trash-identifier-nnvui

Provided by a Roboflow user
License: CC BY 4.0

